from flask import Blueprint

from UseSqlite import RiskQuery
from common import make_html_paragraph

search_bp = Blueprint("search_bp",__name__)

@search_bp.route("/search/<querystring>")
def search(querystring):
    rq=RiskQuery('./static/RiskDB.db')
    rq.instructions(f"SELECT * FROM photo where description = '{querystring}'")
    rq.do()
    record = ''
    for r in rq.format_results().split('\n\n'):
        record+='%s'%(make_html_paragraph(r))
    return record+'</table>\n'
