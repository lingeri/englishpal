from datetime import datetime
from flask import Blueprint, request

from UseSqlite import InsertQuery

upload_bp = Blueprint("upload_bp", __name__)

@upload_bp.route("/upload", methods=['GET', 'POST'])
def upload():
    # 保存图片至本地
    uploaded_file=request.files['file']
    time_str=datetime.now().strftime('%Y%m%d%H%M%S')
    new_filename=time_str+'.jpg'
    uploaded_file.save('./static/upload/'+new_filename)
    time_info=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    description=request.form['description']
    path='./static/upload/'+new_filename
    # 更新数据库
    iq=InsertQuery('./static/RiskDB.db')
    iq.instructions("INSERT INTO photo Values('%s','%s','%s','%s')"%(time_info,description,path,new_filename))
    iq.do()
    return '<p>You have uploaded %s.<br/> <a href="/">Return</a>.'%(uploaded_file.filename)
