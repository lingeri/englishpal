# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 15:42:51 2019

@author: Administrator
"""

from flask import Flask, redirect, url_for

from api import api_bp
from show import show_bp
from search import search_bp
from upload import upload_bp

app=Flask(__name__)

app.register_blueprint(api_bp)
app.register_blueprint(show_bp)
app.register_blueprint(search_bp)
app.register_blueprint(upload_bp)

@app.route('/',methods=['POST','GET'])
def main():
    return redirect(url_for('show_bp.show'))# 暂时重定向
    
if __name__=='__main__':
    app.run(debug=True)