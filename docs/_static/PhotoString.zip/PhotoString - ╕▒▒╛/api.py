import os
import json
from flask import Blueprint

from UseSqlite import RiskQuery

api_bp = Blueprint("api", __name__, url_prefix="/api")

@api_bp.route("/json", methods=['GET', 'POST'])
def toJSON():
    rq=RiskQuery('./static/RiskDB.db')
    rq.instructions("SELECT * FROM photo ORDER By time desc")
    rq.do()
    photo_lst = rq.format_results().split('\n\n')

    for i in range(len(photo_lst)):
        photo = photo_lst[i].split(',')
        photo[2] = f"{os.path.getsize(photo[2].strip()) // 1024} KB"
        photo_lst[i] = photo
    return json.dumps(photo_lst)
